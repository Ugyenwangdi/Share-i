package com.example.android.share_i;

public class Data {

    public String username;

    public Data(String username) {
        this.username = username;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}
